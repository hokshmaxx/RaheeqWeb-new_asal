@extends('admin.users.sideMenu')
@section('companyContent')
	<div class="flex-row-fluid ml-lg-8">
		<!--begin::Row-->
		<div class="row">
		<div class="col-lg-3">
				<!--begin::List Widget 14-->
				<!--<div class="col-xl-3">-->
		<!--begin::Stats Widget 31-->
		<div class="card card-custom bg-danger  gutter-b">
 
	</div>
	   </div>
		</div>
		<!--end::Row-->
		<!--begin::Advance Table: Widget 7-->
	 
		<!--end::Advance Table Widget 7-->
 	</div>
@endsection
