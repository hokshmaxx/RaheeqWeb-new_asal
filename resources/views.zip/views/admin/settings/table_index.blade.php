<td class="v-align-middle wd-5p" style="width: 1px !important;">
    <div class="checkbox-inline">
        <label class="checkbox">
            <input type="checkbox" value="{{$row->id}}" class="checkboxes chkBox" name="chkBox"/>
            <span></span></label>
    </div>
 </td>