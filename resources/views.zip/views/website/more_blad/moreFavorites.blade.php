   @if(count($items) > 0 )
    @foreach($items as $item)
        <div class="col-md-3 product{{@$item->product->id}}">
            <div class="item-product wow fadeInUp">
                <figure>
                   <a href="{{route('prouctDetails',[$item->product->id,Str::slug($item->product->name)])}}"> <img src="{{@$item->product->image}}" alt="" /> </a>
                      <a class="btn_remove removeFromFavoriteItem" data-id="{{@$item->product->id}}"><i class="fa fa-times"></i></a>
            
                    
                    @if(@$item->product->discount_price > 0 && @$item->product->offer_end_date >= now()->toDateString())
                      <span class="offer-product">{{@$item->product->discount_percent}}%</span>
                    @endif
                </figure>
                <div class="txt-product">
                   <a href="{{route('prouctDetails',[$item->product->id,Str::slug($item->product->name)])}}"> <p>{{@$item->product->name}}</p></a>
                    <div>
                         @if(@$item->product->discount_price > 0 && @$item->product->offer_end_date >= now()->toDateString())
                             <del>{{@$item->product->price}} @lang('website.KWD')</del>
                           <strong>{{$item->product->discount_price}} @lang('website.KWD')</strong>
                        @else
                        <strong>{{$item->product->price}} @lang('website.KWD')</strong>
                        @endif
                    </div>
                     <a class="btn-site @if(@$item->product->is_cart==0) addToCart @else removeFromCart @endif" data-id="{{@$item->product->id}}" ><span>@if(@$item->product->is_cart==0) @lang('website.addToCart') @else @lang('website.remove_from_cart') @endif</span></a>
                </div>
            </div>
        </div>
    @endforeach
    @endif