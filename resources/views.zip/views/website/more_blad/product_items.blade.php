   @if(count($products) > 0 )
    @foreach($products as $product)
        <div class="col-md-3">
            <div class="item-product wow fadeInUp">
                <figure>
                  <a href="{{route('prouctDetails',[$product->id,Str::slug($product->name)])}}">  <img src="{{$product->image}}" alt="" /> </a>
                    @if($product->is_favorite==1)
                       <a class="btn_favorite item_fav removeFromFavorite" data-id="{{$product->id}}"><i class="fa fa-heart"></i></a>
                    @elseif($product->is_favorite==0)
                       <a class="btn_favorite addToFavorite" data-id="{{$product->id}}"><i class="fa fa-heart"></i></a>
                    @endif
            
                    
                    @if($product->discount_price > 0 && $product->offer_end_date >= now()->toDateString())
                      <span class="offer-product">{{$product->discount_percent}}%</span>
                    @endif
                </figure>
                <div class="txt-product">
                <a href="{{route('prouctDetails',[$product->id,Str::slug($product->name)])}}">    <p>{{$product->name}}</p> </a>
                    <div>
                         @if($product->discount_price > 0 && $product->offer_end_date >= now()->toDateString())
                        <del>{{$product->price }} @lang('website.KWD')</del>
                        <strong>{{$product->discount_price}} @lang('website.KWD')</strong>
                        @else
                        <strong>{{$product->price}} @lang('website.KWD')</strong>
                        @endif
                    </div>
                    <ul>
                        <!--<li><a href="{{route('prouctDetails',[$product->id,Str::slug($product->name)])}}" class="btn-site"><span>@lang('website.Details')</span></a></li>-->
                        <li><a href="" class="btn-site @if($product->is_cart==0) addToCart @else removeFromCart @endif" data-id="{{$product->id}}"><span>@if($product->is_cart==0) @lang('website.addToCart') @else @lang('website.remove_from_cart') @endif</span></a></li>
                    </ul>
                </div>
            </div>
        </div>
    @endforeach
     @endif