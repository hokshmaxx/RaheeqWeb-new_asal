@extends('website.layout')
@section('title'){{$setting->title}} @endsection
@section('css')
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fancyapps/fancybox@3.5.6/dist/jquery.fancybox.min.css">
@endsection
@section('content')
        <section class="section_home">
            <div class="owl-carousel" id="home_slider">
               @foreach($banners as $banner)
                <div class="item">
                    <a href="{{$banner->link}}">
                        <img src="{{$banner->image}}" alt="Images Slide" />
                    </a>
                </div>
                @endforeach
            </div>
		</section>
		<!--section_home-->
		
		<section class="section_categoris">
		    <div class="container">
		        <div class="sec_head wow fadeInUp">
		            <h2>@lang('website.CATAGORIES')</h2>
		        </div>
		        <div class="owl-carousel" id="categoris_slider">
		            @foreach($categories as $category)
                         <div class="item">
                        <div class="item_categoris">
                            <a href="{{route('category',[$category->id,Str::slug($category->name)])}}">
                                <figure><img src="{{$category->image}}" alt="" /></figure>
                                <p>{{$category->name }}</p>
                            </a>
                        </div>
                    </div>
                    @endforeach
      
                </div>
		    </div>
		</section>
		<!--section_about-->
		
		<section class="section_arrival">
		    <div class="container">
		        <div class="sec_head wow fadeInUp">
		            <h2>@lang('website.New Arrival')</h2>
		        </div>
		        <div class="row">
		       
		            @foreach($products as $product)
		            <div class="col-md-4">
		                <div class="item-product wow fadeInUp">
		                    <figure>
		                       <a href="{{route('prouctDetails',[$product->id,Str::slug($product->name)])}}">  <img src="{{$product->image}}" alt="" /></a> 
                               @if($product->is_favorite==1)
                                   <a class="btn_favorite item_fav removeFromFavorite" data-id="{{$product->id}}"><i class="fa fa-heart"></i></a>
                                @elseif($product->is_favorite==0)
                                   <a class="btn_favorite addToFavorite" data-id="{{$product->id}}"><i class="fa fa-heart"></i></a>
                                @endif
                                @if($product->discount_price > 0 && $product->offer_end_date >= now()->toDateString())
                                  <span class="offer-product">{{$product->discount_percent}}%</span>
                                @endif
                            </figure>
		                    <div class="txt-product">
                               <a href="{{route('prouctDetails',[$product->id,Str::slug($product->name)])}}"><p>{{$product->name}}</p></a> 
                                 <div>
                                     @if($product->discount_price > 0 &&  $product->offer_end_date >= now()->toDateString())
                                    <del>{{$product->price}} @lang('website.KWD')</del>
                                    <strong>{{$product->discount_price}} @lang('website.KWD')</strong>
                                    @else
                                    <strong>{{$product->price}} @lang('website.KWD')</strong>
                                    @endif
                                    
                                </div>
                                <a class="btn-site @if($product->is_cart==0) addToCart @else removeFromCart @endif" data-id="{{$product->id}}"><span>@if($product->is_cart==0) @lang('website.addToCart') @else @lang('website.remove_from_cart') @endif</span></a>
		                    </div>
		                </div>
		            </div>
		            @endforeach  
		        </div>
		         <a href="{{route('NewArrival')}}" class="btn-site"><span>@lang('website.View all')</span></a>
		    </div>
		</section>
		<!--section_arrival-->
		
		<section class="section_video" style="background: url({{$setting->home_vedio_image}})">
		    <div class="box-click">
		        <a data-fancybox="images" href="{{$setting->home_vedio_link}}"><i class="fa fa-play"></i></a>  
		    </div>
		</section>
		<!--section_video-->
		
		<section class="section_contact">
		    <div class="container">
		        <div class="sec_head wow fadeInUp">
		            <h2>@lang('website.Contact us')</h2>
		        </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="img-contact">
                            <img src="{{url('website/images/contact.png')}}" alt="" />
                        </div>
                    </div>
                    <div class="col-md-6">
                        <form class="form-contact" id="contactForm">
                            <div class="form-group">
                                <input type="text" class="form-control" name="name" id="full_name" placeholder="{{__('website.name')}}" required />
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control" name="emaill" id="emaill" placeholder="{{__('website.email')}}" required />
                            </div>
                            <div class="form-group">
                                <textarea class="form-control" name="message" id="Messagee" placeholder="{{__('website.message')}}" required></textarea>
                            </div>
                            <div class="form-group">
                                <button class="btn-site contact_us"><span>@lang('website.send')</span></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>

@endsection

@section('script')
<script src="https://cdn.jsdelivr.net/npm/@fancyapps/fancybox@3.5.6/dist/jquery.fancybox.min.js"></script>
	<script>

        $(document).on('click','input,select,textarea,.select2',function(){
        //   jQuery.noConflict();
            $(this).attr('style',"").next('span.errorSpan').remove();//
        });
        var preventSubmit = false;
        
	
	$(document).on('click','.contact_us',function (e) {
        // $(".remove-from-cart").click(function (e) {
            e.preventDefault();

            $(this).closest("#contactForm").find( 'select, textarea, input' ).each(function(){
                  if($(this).prop('required') && !$(this).val() && !$(this).is(":hidden")){
                      $(this).css("border", "#ff0000 solid 1px").next('span.errorSpan').remove(); //
                           $(this).css("border", "#bd1616 solid 1px").after('<span style="color:#bd1616" class="errorSpan">{{__("website.requiredField")}}</span>');
                      preventSubmit = true;
                      e.preventDefault();
                  }
              });
              if(preventSubmit){
                  preventSubmit = false;
                  return false;
                  
              }
 
        var ele = $(this);
        var id = $(this).data("id");
        var product_id = $(this).data("product_id");

        $.ajax({
            url: '{{url(app()->getLocale().'/contact_us')}}', 
            type: "post", 
            data: {
                _token: '{{ csrf_token() }}',
                name: $('#full_name').val(),  
                email: $('#emaill').val(),  
                mobile: $('#mobilee').val(),  
                message: $('#Messagee').val(),          
            },
            success: function (response) {
            // return response;
                if(response.code ==300){
                //  $("#completO, #completeT").hide(2000);
                //    jQuery.noConflict();
                    swal({
                        title: "{{__('website.ok')}}",
                        icon: "success",
                        button: "{{__('website.oky')}}",
                    });
                    $('#full_name').val('');
                    $('#emaill').val('');
                    $('#Messagee').val('');   
                    $('#mobilee').val('');   
                }else if(response.validator !=null){    
                            swal({
                            text: response.validator,
                            button: "{{__('website.oky')}}",
                            dangerMode: true,
                        });
                } else{
                    swal(response.message)
                }
            } 
            
        });
    });

		new WOW().init();
	</script>
	
@endsection

