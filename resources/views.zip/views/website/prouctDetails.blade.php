@extends('website.layout')
@section('title') {{$product->name}} @endsection
@section('css')
@endsection

@section('socialMeta')
    <meta property="og:url"                content="{{Request::fullUrl()}}" />
    <meta property="og:type"               content="article" />
    <meta property="og:title"              content="{{$product->name}}" />
    <meta property="og:description"        content="{{str_limit(strip_tags($product->description) ,  200)}}" />
    <meta property="og:image"              content="{{url($product->image)}}" />
    <meta property="fb:app_id" 			   content="17734562" />

    <meta name="twitter:card" content="summary" />
    <meta name="twitter:site" content="@pido" />
    <meta name="twitter:creator" content="@pido" />
    <meta name="twitter:title" content="{{$product->name}}" />
    <meta name="twitter:description" content="{{str_limit(strip_tags($product->description) ,  200)}}" />
    <meta name="twitter:image" content="{{url($product->image)}}" />
@endsection

@section('content')

 
         <div class="breadcrumb-bar">
			<div class="container">
				<ol class="breadcrumb">
				  <li class="breadcrumb-item"><a href="{{route('home')}}"><i class="fa fa-home"></i>@lang('website.HOME')</a></li>
				  <li class="breadcrumb-item"><a href="{{route('category',[$product->category->id,Str::slug($product->category->name)])}}">{{$product->category->name}}</a></li>
				  <li class="breadcrumb-item active">{{$product->name}} </li>
				</ol>
			</div>
		</div>
		<!--breadcrumb-bar-->
      	
		<section class="section_page_site">
		    <div class="container">
                <div class="row">
                    <div class="col-md-5">
                        <div class="block-product-slide">
                            <div class="slider slider-for clearfix">
                                @foreach($product->images as $item)
                                <div class="pro-slide-item">
                                    <div class="pro--Thumb slider-for__item ex1" data-src="{{$item->image}}">
                                        <img src="{{$item->image}}" alt="" />
                                    </div>
                                </div>
                                @endforeach

                            </div>
                             
                            <div class="slider slider-nav clearfix">
                                @foreach($product->images as $item)
                                <div class="sp-nav">
                                    <img src="{{$item->image}}" alt="" class="img-responsive">
                                </div>
                                @endforeach
                            </div>
                            
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="nam-prod">
                            <h4 style="color:#000">{{$product->name}}</h4>
                            <p>{{$product->price}} @lang('website.KWD')</p>
                        </div>
                        <div class="des-prod">
                            <h5>@lang('website.Description')</h5>
                            <p>{{$product->description}} </p>
                            <div class="sku-prod">
                                <p>@lang('website.SKU')</p>
                                <p>{{$product->sku}}</p>
                            </div>
                            @if($product->quantity < 1)
                            <div class="soldOut">
                                <strong>@lang('website.Sold Out')</strong>
                            </div>
                            @endif
                        </div>
                        <div class="opt-product">
                        @if($product->quantity >= 1)
                            <div class="count-prod ">
                                <h6>@lang('website.Count')</h6>
                                <div class="quantity-item">
                                    <div class="quantity">
                                        <div class="btn button-count inc jsQuantityIncrease" data-id="{{@$product->id}}">
                                            <i class="fa fa-plus" aria-hidden="true"></i>
                                        </div>
                                        @if($product->is_cart >0)
                                        <input type="text" name="count-quat1" class="count-quat quantity_input" value="{{$product->is_cart}}">
                                        @else
                                          <input type="text" name="count-quat1" class="count-quat quantity_input" value="1">
                                        @endif
                                        <div class="btn button-count dec jsQuantityDecrease @if($product->is_cart ==0 || $product->is_cart ==1) disabled @endif"  minimum="1" data-id="{{@$product->id}}">
                                            <i class="fa fa-minus" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endif
                            <ul>
                               @if($product->quantity >= 1)
                                  <li><a href="" class="btn-site @if($product->is_cart==0) addToCart @else removeFromCart @endif" data-id="{{$product->id}}"><span>@if($product->is_cart==0) @lang('website.addToCart') @else @lang('website.remove_from_cart') @endif</span></a></li>
                                @endif
                                <li>
                                   
                            
                                     @if($product->is_favorite==1)
                                       <a class="btn-site item_fav removeFromFavoritePage" data-id="{{$product->id}}"><span class="ti-trash"></span></a>
                                    @elseif($product->is_favorite==0)
                                       <a class="btn-site addToFavoritePage" data-id="{{$product->id}}"><span class="ti-heart"></span></a>
                                    @endif
                                    </li>
                                <li><a href="https://www.facebook.com/sharer/sharer.php?u={{url(app()->getLocale().'/products/'.$product->id.'/'.slugURL($product->name))}}" class="btn-site"><span class="fa fa-share-alt"></span></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
		    </div>
		</section>
		
		     <section class="section_similar">
            <div class="container">
                <div class="sec-head">
                    <h2>@lang('website.Similar Products') </h2>
                </div>
                <div class="owl-carousel" id="similar_slider">
                    @foreach($products as $one)
                    <div class="item">
                        <div class="item-product">
		                    <figure>
		                    <a href="{{route('prouctDetails',[$one->id,Str::slug($one->name)])}}">    <img src="{{$one->image}}" alt="" /> </a>
                                    @if($one->is_favorite==1)
                                       <a class="btn_favorite item_fav removeFromFavorite" data-id="{{$one->id}}"><i class="fa fa-heart"></i></a>
                                    @elseif($one->is_favorite==0)
                                       <a class="btn_favorite addToFavorite" data-id="{{$one->id}}"><i class="fa fa-heart"></i></a>
                                    @endif
                                    
                            @if($one->discount_price > 0 && $one->offer_end_date >= now()->toDateString())
                              <span class="offer-product">{{$one->discount_percent}}%</span>
                            @endif
                            </figure>
		                    <div class="txt-product">
                               <a href="{{route('prouctDetails',[$one->id,Str::slug($one->name)])}}"> <p>{{$one->name}}</p> </a>
                                <div>
                             @if($one->discount_price > 0 && $one->offer_end_date >= now()->toDateString())
                            <del>{{$one->price}} @lang('website.KWD')</del>
                            <strong>{{$one->discount_price}} @lang('website.KWD')</strong>
                            @else
                            <strong>{{$one->price}} @lang('website.KWD')</strong>
                            @endif
                            </div>
                                <a class="btn-site @if($one->is_cart==0) addToCart @else removeFromCart @endif" data-id="{{$one->id}}"><span>@if($one->is_cart==0) @lang('website.addToCart') @else @lang('website.remove_from_cart') @endif</span></a>
		                    </div>
		                </div>
                    </div>
                    @endforeach
                
                </div>
            </div>
        </section>
@endsection

@section('script')
 
 	<script type="text/javascript">
        var check=false;
        @if(app()->getLocale() === 'ar')
            check=true;
        @endif
		$('.slider-for').slick({
	      slidesToShow: 1,
	      slidesToScroll: 1,
	      fade: true,
	      arrows: false,
	      rtl:check,
	      asNavFor: '.slider-nav'
	    });
	    $('.slider-nav').slick({
	      
	        slidesToShow: 4,
	        slidesToScroll: 1,
	        autoplay: false,
	        asNavFor: '.slider-for',
	        dots: false,
	        focusOnSelect: true,
	        centerMode: true,
            arrows: false,
	        vertical: true,
            verticalSwiping: true,

	        responsive: [
		    {
		      breakpoint: 600,
		      settings: {
		      	slidesToShow: 3,
		      	vertical: true,
		      	centerMode: true,
		      }
		    }
		    ],
	        speed: 1000,
	        autoplaySpeed: 2000,
	        useTransform: true,
	        cssEase: 'cubic-bezier(0.645, 0.045, 0.355, 1.000)',
//	        prevArrow:"<i class='fa fa-angle-up' aria-hidden='true'></i>",
//	        nextArrow:"<i class='fa fa-angle-down' aria-hidden='true'></i>"
	    });
	</script>
	
	<script>
	    
	               $(document).on('click','.addToFavoritePage',function (e) {
              e.preventDefault();
                    @if(!auth()->check())
                       return;
                    @endif
               var ele = $(this);
               var id = $(this).data("id"); 

              $.ajax({
                    url: '{{url(app()->getLocale().'/addToFavorite')}}'+'/'+id, 
            		headers: {
                          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                      },
                    method: "get", 
                    data: {
                    },
                    success: function (response) {
                        if(response.code==200){
                             ele.removeClass('addToFavoritePage').addClass('removeFromFavoritePage').fadeTo(100, 0.3, function() { $(this).fadeTo(500, 1.0); });
                             ele.find('span').removeClass('ti-heart').addClass('ti-trash');
                        }
                     

                    }
                  
              });
          });
          
        $(document).on('click','.removeFromFavoritePage',function (e) {
              e.preventDefault();
                    @if(!auth()->check())
                       return;
                    @endif
              var ele = $(this);
               var id = $(this).data("id");  
              $.ajax({
                    url: '{{url(app()->getLocale().'/removeFromFavorite')}}'+'/'+id, 
            		headers: {
                          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                      },
                    method: "get", 
                    data: {
                    },
                    success: function (response) {
                       ele.removeClass('removeFromFavoritePage').removeClass('item_fav').addClass('addToFavoritePage');
                         ele.find('span').removeClass('ti-trash').addClass('ti-heart');
                       
                    }
                  
              });
          });
	</script>
@endsection

