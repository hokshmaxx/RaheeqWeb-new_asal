@extends('website.layout')
@section('title') @lang('website.My Favorites')@endsection
@section('css')
@endsection
@section('content')

 
        
        <section class="section_page_site">
		    <div class="container">
 
		        <div class="row" id="infinite">
		           @include('website.more_blad.moreFavorites')

		        </div>
		        
		         {{$items->links('pagination::bootstrap-4')}}
		        <!--<div class="ajax-load text-center" style="display:none">-->
          <!--           <div class="loadingIconsItems" style="text-align:center"><i class="fa fa-spinner fa-spin" style="font-size: 20px;"></i></div>-->
          <!--      </div>-->
                    
		    </div>
		</section>

@endsection

@section('script')
 <script>
             $(document).on('click','.removeFromFavoriteItem',function (e) {
              e.preventDefault();
                    @if(!auth()->check())
                       return;
                    @endif
              var ele = $(this);
               var id = $(this).data("id");
              $.ajax({
                    url: '{{url(app()->getLocale().'/removeFromFavorite')}}'+'/'+id, 
            		headers: {
                          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                      },
                    method: "get", 
                    data: {
                    },
                    success: function (response) {
                       $('.product'+id).hide(200).remove;
                       
                    }
                  
              });
          });
          
          
          
                  var csrf_token = '{{csrf_token()}}';
        var page = 1;
        // $(window).scroll(function () {
        //     if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight -350) {
        //         if(page !=0) {
        //             page++;
        //             loadMoreData(page);
        //         }
        //     }
        //     else {
        //     }
        // });
function loadMoreData(page1) {
    var char;
    if(window.location.search == ""){
        char = "?";
    }else{
        char = window.location.href+"&";
    }
    $.ajax(
        {
            url: char +'page=' + page1,
            type: "get",
            beforeSend: function () {
                $('.ajax-load').show();
            }
        })
        .done(function (data) {
            $('.ajax-load').hide();
            $("#infinite").append(data.html);
            if ( data.is_more =="no") {
                $('.ajax-load').hide(); 
                page = 0;
                return;
            }
        })
        .fail(function (jqXHR, ajaxOptions, thrownError) {
            return false;
        });
}
 
 </script>
	
@endsection

