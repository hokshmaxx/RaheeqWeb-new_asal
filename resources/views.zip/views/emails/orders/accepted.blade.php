<p>تم قبول طلبك بنجاح</p>

</br>
</br>
<hr>
<p>Your order accepted succesfully</p>
</br>
</br>
<hr>
<p>email:  {{$email}}</p>
<p>password: {{$password}}}</p>